<?php
// filepath: d:\Programming\Web Programming 2.0\Course_Project\index.php
require_once 'config/database.php';

$error = "";
$clipboard_id_value = "";

// Function to generate unique clipboard ID
function generateUniqueClipboardId($pdo) {
    do {
        $clipboard_id = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM clipboards WHERE clipboard_id = ?");
        $stmt->execute([$clipboard_id]);
        $exists = $stmt->fetchColumn() > 0;
    } while ($exists);
    
    return $clipboard_id;
}

// Function to clean expired entries
function cleanExpiredEntries($pdo) {
    $stmt = $pdo->prepare("DELETE FROM clipboards WHERE expires_at < NOW()");
    $stmt->execute();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $database = new Database();
        $pdo = $database->getConnection();
        
        // Clean expired entries
        cleanExpiredEntries($pdo);
        
        // Handle generate button
        if (isset($_POST['generate'])) {
            $clipboard_id_value = generateUniqueClipboardId($pdo);
            
            // Insert new clipboard entry
            $stmt = $pdo->prepare("INSERT INTO clipboards (clipboard_id, content_type) VALUES (?, 'empty')");
            $stmt->execute([$clipboard_id_value]);
            
            header("Location: content.php?clipboard_id=" . urlencode($clipboard_id_value));
            exit;
        }
        
        // Handle join button
        if (isset($_POST["clipboard_id"]) && !empty($_POST["clipboard_id"])) {
            $clipboard_id_value = $_POST["clipboard_id"];

            // Check if it is exactly 6 digits
            if (!preg_match('/^\d{6}$/', $clipboard_id_value)) {
                $error = "Invalid ID. Must be a 6-digit number.";
            } else {
                // Check if clipboard exists in database
                $stmt = $pdo->prepare("SELECT clipboard_id FROM clipboards WHERE clipboard_id = ? AND expires_at > NOW()");
                $stmt->execute([$clipboard_id_value]);
                
                if ($stmt->rowCount() > 0) {
                    header("Location: content.php?clipboard_id=" . urlencode($clipboard_id_value));
                    exit;
                } else {
                    $error = "Clipboard not found or has expired.";
                }
            }
        } else {
            $error = "Please enter a clipboard ID.";
        }
    } catch (Exception $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cloud Clipboard | Online Clipboard for Instant Text & Image Sharing | Collaborative Board</title>
    <link rel="stylesheet" href="./style/style.css">
    <link rel="icon" href="./asset/fav.png" type="image/png">
</head>

<body>
    <header>
        <ul class="mobile-menu">
            <li class="control">
                <div>
                    <img onclick="closeMenu()" src="./asset/close_menu.svg" alt="close Menu">
                </div>
                <div>
                    <img class="rotateImg" src="./asset/mode.svg" alt="mode">
            </li>
            </div>
            <li onclick="closeMenu()"><a href="#">Home</a></li>
            <li onclick="closeMenu()"><a href="#">About</a></li>
            <li onclick="closeMenu()"><a href="#">Updates</a></li>
            <li onclick="closeMenu()"><a href="#">Feedback</a></li>
        </ul>
        <nav class="section-wide" id="marTop">
            <img onclick="toggleMenu()" src="./asset/menu.svg" alt="menu Icon" class="menu-icon">
            <div class="logo">
                <figure>
                    <a href="./index.php"><img src="./asset/logo.png" alt="Logo"></a>
                </figure>
                <span class="logo-text">Cloud Clipboard</span>
            </div>
            <ul class="mobile-menu">
                <li class="control">
                    <div>
                        <img src="./asset/close_menu.svg" alt="close Menu">
                    </div>
                    <div>
                        <img class="rotateImg" src="./asset/mode.svg" alt="mode">
                </li>
                </div>
                <li><a href="./index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Updates</a></li>
                <li><a href="#">Feedback</a></li>
            </ul>
            <ul class="nav-links">
                <li><img class="rotateImg" src="./asset/mode.svg" alt="mode"></li>
                <li><a href="./index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Updates</a></li>
                <li><a href="#">Feedback</a></li>
            </ul>
        </nav>
    </header>

    <main id="mainContent">
        <section class="section-wide image-section">
            <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.6.2/dist/dotlottie-wc.js" type="module"></script>
            <dotlottie-wc src="https://lottie.host/c7363849-bc39-47c9-88f2-4bc27afb42cf/UVGh4V7fib.lottie"
                style="max-width: 400px;height: 400px" speed="1" autoplay loop></dotlottie-wc>
        </section>
        <section class="section-wide functional-section">
            <div class="text-section">
                <h1>Cloud Clipboard</h1>
                <p>Share text and images instantly with Cloud Clipboard. No sign-up required, just copy and paste!</p>
            </div>
            <div class="functional-buttons">
                <div>
                    <p>Create a new Clipboard...</p>
                    <form method="post" action="">
                        <button type="submit" class="primary-button" name="generate">Create Clipboard</button>
                    </form>
                </div>
                <div>
                    <p>Join an existing Clipboard...</p>
                    <div class="input-container">
                        <form action="" method="post">
                            <input type="text" name="clipboard_id" placeholder="Enter Clipboard ID"
                                value="<?php echo htmlspecialchars($clipboard_id_value); ?>" required>
                            <button class="secondary-button">Join</button>
                        </form>

                        <p class="error-message" id="error-message"
                            style="display: <?php echo $error ? 'block' : 'none'; ?>;">
                            <?php echo $error; ?>
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer class="section-wide section-top">
        <ul class="footer-links">
            <li><a href="#">About</a></li>
            <li class="borderLeft"><a href="#">Privacy Policy</a></li>
            <li class="borderLeft"><a href="#">Terms of Service</a></li>
            <li class="borderLeft"><a href="#">Contact Us</a></li>
        </ul>
        <hr>
        <p><small>&copy; 2025 Cloud Clipboard. All rights reserved.</small></p>
    </footer>
    <script src="./script/header-script.js"></script>
</body>

</html>